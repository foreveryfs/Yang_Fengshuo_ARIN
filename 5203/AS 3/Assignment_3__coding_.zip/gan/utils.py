import argparse
import torch
from cleanfid import fid
from matplotlib import pyplot as plt
from torchvision.utils import save_image


def save_plot(x, y, xlabel, ylabel, title, filename):
    plt.plot(x, y)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.title(title)
    plt.savefig(filename + ".png")


@torch.no_grad()
def get_fid(gen, dataset_name, dataset_resolution, z_dimension, batch_size, num_gen):
    gen_fn = lambda z: (gen.forward_given_samples(z) / 2 + 0.5) * 255
    score = fid.compute_fid(
        gen=gen_fn,
        dataset_name=dataset_name,
        dataset_res=dataset_resolution,
        num_gen=num_gen,
        z_dim=z_dimension,
        batch_size=batch_size,
        verbose=True,
        dataset_split="custom",
    )
    return score


@torch.no_grad()
def interpolate_latent_space(gen, path):
    ##################################################################
    # TODO: 1.2: Generate and save out latent space interpolations.
    # 1. Generate 100 samples of 128-dim vectors. Do so by linearly
    # interpolating for 10 steps across each of the first two
    # dimensions between -1 and 1. Keep the rest of the z vector for
    # the samples to be some fixed value (e.g. 0).
    # 2. Forward the samples through the generator.
    # 3. Save out an image holding all 100 samples.
    # Use torchvision.utils.save_image to save out the visualization.
    ##################################################################
    device = next(gen.parameters()).device
    # Step 1 :
    num_steps = 10
    z_interp = torch.zeros(num_steps * num_steps, 128, device=device)
    # First two dimensions
    dim1 = torch.linspace(-1, 1, num_steps, device=device) 
    dim2 = torch.linspace(-1, 1, num_steps, device=device)  
    # Interpolating
    for i in range(num_steps):
        for j in range(num_steps):
            idx = i * num_steps + j
            z_interp[idx, 0] = dim1[i]
            z_interp[idx, 1] = dim2[j]

    # Step 2 :
    gen_images = gen.forward_given_samples(z_interp)
    gen_images = (gen_images +1.0) / 2.0

    # Step 3 :   
    save_image(
        gen_images,
        path,
        nrow=num_steps,
        padding=2,
        normalize=False
    )          
    ##################################################################
    #                          END OF YOUR CODE                      #
    ##################################################################

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--disable_amp", action="store_true")
    args = parser.parse_args()
    return args
